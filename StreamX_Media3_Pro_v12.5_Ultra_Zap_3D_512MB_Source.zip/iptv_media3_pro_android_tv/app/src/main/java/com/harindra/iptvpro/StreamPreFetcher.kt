package com.harindra.iptvpro

import android.content.Context
import android.util.Log
import android.util.LruCache
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.Request
import java.util.Collections

/**
 * v12.5 Ultra-Fast Direct-RAM Socket & Live Manifest Pre-Warmer for 512MB RAM Android TVs.
 *
 * ZERO Disk / SQLite I/O during channel zapping:
 * Instead of writing live .m3u8 manifests to slow eMMC flash (which causes stale HLS playlists
 * and disk lock delays), this engine warms DNS + TCP + TLS + HTTP/2 sockets directly in RAM
 * on NetworkClient.streamClient so ExoPlayer connects to the real-time live edge in ~0ms.
 */
object StreamPreFetcher {
    private const val MIN_FREE_HEAP_FOR_PREFETCH = 14L * 1024L * 1024L // 14 MB safety floor

    private val prefetchScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var adjacentJob: Job? = null
    private var focusJob: Job? = null
    private var top8WarmupJob: Job? = null

    // Lightweight in-memory LRU tracking recently warmed stream hosts/URLs (<64 KB RAM total)
    private val warmedSocketTimestamps = object : LruCache<String, Long>(64) {}
    private val activeWarmupSet = Collections.synchronizedSet(HashSet<String>(16))

    private fun hasSafeHeapForPrefetch(): Boolean {
        val rt = Runtime.getRuntime()
        val freeAndUnallocated = rt.maxMemory() - (rt.totalMemory() - rt.freeMemory())
        return freeAndUnallocated >= MIN_FREE_HEAP_FOR_PREFETCH
    }

    /**
     * Tier 1: Silently pre-warm HTTP/2 + TLS sockets + live edge for N+1 and N-1 channels in RAM.
     */
    fun scheduleAdjacentPrefetch(
        @Suppress("UNUSED_PARAMETER") context: Context,
        nextUrl: String?,
        prevUrl: String?
    ) {
        adjacentJob?.cancel()
        adjacentJob = prefetchScope.launch {
            delay(220L) // Wait briefly so active channel gets 100% bandwidth for Frame 1
            if (!isActive || !hasSafeHeapForPrefetch()) return@launch
            if (!nextUrl.isNullOrBlank()) {
                warmLiveConnectionInRam(nextUrl)
            }
            if (!isActive || !hasSafeHeapForPrefetch()) return@launch
            if (!prevUrl.isNullOrBlank() && prevUrl != nextUrl) {
                warmLiveConnectionInRam(prevUrl)
            }
        }
    }

    /**
     * Tier 2: When user highlights a channel in the drawer for >120ms, pre-warm its socket in RAM before OK is pressed.
     */
    fun scheduleFocusPrefetch(
        @Suppress("UNUSED_PARAMETER") context: Context,
        focusedUrl: String?
    ) {
        focusJob?.cancel()
        if (focusedUrl.isNullOrBlank()) return
        focusJob = prefetchScope.launch {
            delay(120L) // Fast 120ms D-Pad focus pre-warm
            if (!isActive || !hasSafeHeapForPrefetch()) return@launch
            warmLiveConnectionInRam(focusedUrl)
        }
    }

    /**
     * Tier 3: During stable playback, keep sockets warm for Top-8 Favorite/Recent channels.
     */
    fun scheduleTop8Warmup(
        @Suppress("UNUSED_PARAMETER") context: Context,
        topUrls: List<String>
    ) {
        top8WarmupJob?.cancel()
        if (topUrls.isEmpty()) return
        top8WarmupJob = prefetchScope.launch {
            delay(2500L)
            for (url in topUrls.take(8)) {
                if (!isActive || !hasSafeHeapForPrefetch()) break
                warmLiveConnectionInRam(url)
                delay(500L)
            }
        }
    }

    private fun warmLiveConnectionInRam(streamUrl: String) {
        if (!streamUrl.startsWith("http://", true) && !streamUrl.startsWith("https://", true)) return
        val now = System.currentTimeMillis()
        val lastWarmed = synchronized(warmedSocketTimestamps) { warmedSocketTimestamps.get(streamUrl) }
        if (lastWarmed != null && (now - lastWarmed) < 25_000L) {
            return // Connection already warm in OkHttp ConnectionPool
        }
        if (!activeWarmupSet.add(streamUrl)) return
        try {
            val req = Request.Builder()
                .url(streamUrl)
                .header("User-Agent", "StreamX-Media3Pro/12.5-Ultra512MB (AndroidTV)")
                .header("Range", "bytes=0-1023")
                .get()
                .build()
            NetworkClient.streamClient.newCall(req).execute().use { res ->
                val stream = res.body?.byteStream()
                if (stream != null) {
                    val buf = ByteArray(1024)
                    stream.read(buf)
                }
            }
            synchronized(warmedSocketTimestamps) {
                warmedSocketTimestamps.put(streamUrl, System.currentTimeMillis())
            }
        } catch (e: Exception) {
            Log.d("StreamX", "RAM socket warm skipped: ${e.message}")
        } finally {
            activeWarmupSet.remove(streamUrl)
        }
    }

    fun cancelAllPrefetches() {
        adjacentJob?.cancel()
        focusJob?.cancel()
        top8WarmupJob?.cancel()
    }

    fun trimIdleCacheOnLowMemory() {
        cancelAllPrefetches()
        synchronized(warmedSocketTimestamps) {
            warmedSocketTimestamps.evictAll()
        }
    }

    fun cacheUsedBytes(): Long {
        return synchronized(warmedSocketTimestamps) {
            warmedSocketTimestamps.size() * 1024L
        }
    }
}
