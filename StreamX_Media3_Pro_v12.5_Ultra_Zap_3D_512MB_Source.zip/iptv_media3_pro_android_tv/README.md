# StreamX Media3 Pro — 5.2.0 Ultimate Source Project

This revision preserves the existing dark glass / cyan UI and all existing player features while updating the playback/network foundation.

## Main updates
- AndroidX Media3 1.11.1 stable across all Media3 artifacts.
- Premium DTH startup overlay retained until the first rendered video frame, with a bounded fallback for offline/slow providers.
- Existing M3U and Xtream profiles, encrypted credentials, local M3U import, EPG, favorites, recents, search, categories, channel logos, TV remote navigation, sleep timer and aspect-ratio controls retained.
- Isolated bounded HTTP dispatchers for metadata, playlist/EPG and live stream traffic.
- More tolerant live segment read timeout, bounded retries and existing adaptive buffer profiles retained.
- Lower live-playback memory retention and audio focus/noisy-output handling.
- Unit tests for M3U parsing and CI build workflow.

## Compatibility
- Minimum Android version: Android 6.0 (API 23).
- Compile SDK: 36; target SDK remains 34 to avoid an unrelated target-behavior migration in this release.
- JDK 17, Android Gradle Plugin 8.13.2, Gradle 8.13 and Kotlin 2.2.20.
- Android 5.x devices (API 21–22) are not supported by this Media3 1.11.1 build.

## Build in Android Studio
1. Open the `iptv_media3_pro_android_tv` folder.
2. Use JDK 17 and install Android SDK Platform 36.
3. Sync Gradle using Gradle 8.13.
4. Run `testDebugUnitTest`.
5. Build `assembleDebug` and `assembleRelease`.

The project archive contains source code, not a prebuilt APK. This workspace does not have Android SDK/Gradle installed, so APK compilation was not run here. The GitHub Actions workflow runs unit tests and both APK builds when the project is pushed to a GitHub repository.

## Playback caveat
A first-frame startup overlay reduces the chance of showing a blank player surface, but cannot guarantee zero black flashes or zero buffering on every TV. Provider response, network quality, stream format, decoder support and firmware remain external factors. Test on the actual target TV and with authorized streams before release.

## Security and lawful use
Only use playlist URLs, EPG feeds and Xtream credentials you are authorized to access. Credentials remain encrypted at rest. HTTP playlist support is retained for providers that do not offer HTTPS; prefer HTTPS where available.
